# MiniProject_Cpp
|Codacy|cppcheck|Valgrind|Cmake Build|Build|Unit-Test|
|:--:|:--:|:--:|:--:|:--:|:--:|
|[![Codacy Badge](https://app.codacy.com/project/badge/Grade/8690efc1a4b24c0691dcd90080042c01)](https://www.codacy.com/gh/99002646/MiniProject_Cpp/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=99002646/MiniProject_Cpp&amp;utm_campaign=Badge_Grade)|![cppcheck-action](https://github.com/99002646/MiniProject_Cpp/workflows/cppcheck-action/badge.svg?branch=main)|![Valgrind](https://github.com/99002646/MiniProject_Cpp/workflows/Valgrind/badge.svg?branch=main)|![C/C++ CI/Cmake](https://github.com/99002508/Indata-Sudoku/workflows/C/C++%20CI/Cmake/badge.svg)|![C/C++ CI](https://github.com/99002646/MiniProject_Cpp/workflows/C/C++%20CI/badge.svg?branch=main)|![Unit testing](https://github.com/99002646/MiniProject_Cpp/workflows/Unit%20testing/badge.svg?branch=main)|


The project aims at developing a C++ application program, that allows the user to take appointment with doctore.
