#include <iostream>
int main(){
    int widthForX{5};          //brace initialization
    std::cout<<widthForX<<"\n";
    return 0;
}