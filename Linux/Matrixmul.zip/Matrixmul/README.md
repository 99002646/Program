# Multi-Threaded-Matrix-Multiplication
Time Comparison when using different number of Threads for Matrix Multiplication

Two files named - "MatrixA.txt" & "MatrixB.cpp" will feed the program with the values for the 2 matrices.
The values in these files can be changed.

Inoder to compare the different computational speeds, specifiy the different number of threads when asked. You need not run the
program everytime. There is an infinite loops which asks for your input & exits only when you press 'n'.
